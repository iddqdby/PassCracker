#ifndef __STDAFX_H__INCLUDED__
#define __STDAFX_H__INCLUDED__

#include "../p7zip/CPP/myWindows/StdAfx.h"

#endif // __STDAFX_H__INCLUDED__
