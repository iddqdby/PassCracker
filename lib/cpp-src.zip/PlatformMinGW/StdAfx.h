#ifndef __STDAFX_H__INCLUDED__
#define __STDAFX_H__INCLUDED__

#include <windows.h>
#include <time.h>

#endif // __STDAFX_H__INCLUDED__
